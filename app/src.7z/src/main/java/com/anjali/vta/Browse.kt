package com.anjali.vta

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView

class Browse : AppCompatActivity() {
    private lateinit var listview:ListView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browse)
        listview = findViewById(R.id.listv)
        // Step 1: Define your data
        val dataArray = arrayOf("Construction", "Information Technology", "Automobile", "Hotel Management", "Hair and Beauty")

// Step 2: Set up the ListView in your layout XML file (e.g., activity_main.xml)
// <ListView
// android:id="@+id/listView"
// android:layout_width="match_parent"
// android:layout_height="match_parent" />

// Step 3: Create an adapter
        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, dataArray)

// Step 4: Bind the adapter to the ListView

        listview.adapter = adapter
    }
}