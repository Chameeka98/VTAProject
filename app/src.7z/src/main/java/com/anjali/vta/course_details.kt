package com.anjali.vta

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class course_details : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_course_details)
    }
}